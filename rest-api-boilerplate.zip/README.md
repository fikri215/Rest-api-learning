## Laravel 7 API Boilerplate 
vanilla Laravel 7 that's just configured to use tymon\jwt-auth

## To DO
- roles & permissions (maybe implement an existing package)
